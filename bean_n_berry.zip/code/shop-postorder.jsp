<%@ page language="java" contentType="text/html" import="prasann.shop.*,java.util.*,java.sql.*" errorPage="errorpage.jsp" %>
<HTML>
<HEAD>
<TITLE>M-Kart Shopping website in Java JSP</TITLE>
<link rel="stylesheet" href="style.css" type ="text/css">
 <link href="menu_assets/styles.css" rel="stylesheet" type="text/css" />
</HEAD>

<BODY>
<div id ="wrapper">
<div id ="banner">
<img src="header.jpg"height="172" width="1075">
</div>
 <div id ="navigation">
   <div id='cssmenu'>
<ul>
   <li><a href='shop-products.jsp'><span>Home</span></a></li>
   <li><a href='aboutus.jsp'><span>About us</span></a></li>
   <li><a href='shop-basket.jsp'><span>view cart</span></a></li>
   <li><a href='contactus.jsp'><span>contact us</span></a></li>
</ul>
      </ul>
   </div>
    </div>
   <br>
   <div id="content_area">
<h1>Your Shopping Cart </h1>
<jsp:useBean id ="basket" class="prasann.shop.ShoppingBasket" scope = "session"/>
<% 
long order_id=0;
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saurav","singh");

Statement stmt = con.createStatement();
ResultSet rs = stmt.executeQuery("select order_id from order_info");
int i=0;
while(rs.next())
{
	if( i < rs.getInt(1))
		i = rs.getInt(1);
}
order_id=++i;

stmt.close();


String query="insert into orders values ("+order_id+",?,?,?,?,?,?,?)";
PreparedStatement pstmt = con.prepareStatement(query);

pstmt.setString(1,request.getParameter("firstname"));
pstmt.setString(2,request.getParameter("surname"));
pstmt.setString(3,request.getParameter("address"));
pstmt.setString(4,request.getParameter("postcode"));
pstmt.setString(5,request.getParameter("cardnumber"));
pstmt.setString(6,request.getParameter("cardtype"));
pstmt.setDouble(7,Double.parseDouble(request.getParameter("totalvalue")));
pstmt.executeUpdate();
pstmt.close();
//long order_id = ((oracle.jdbc.PreparedStatement)pstmt).getLastInsertID();
PreparedStatement pstmt1=null;
String order_info_query = "insert into order_info values(?,?,?,?)";
Enumeration products = basket.getProducts();
int c=0;
String t;

while(products.hasMoreElements())
{
	++c;
	t =Integer.toString(c);
	  Product product =(Product)products.nextElement();
	  pstmt1=con.prepareStatement(order_info_query);
	  pstmt1.setString(1,t);
	  pstmt1.setLong(2,order_id);
	  pstmt1.setInt(3,Integer.parseInt(product.getId()));
	  pstmt1.setInt(4,product.getQuantity());
	  pstmt1.executeUpdate();
}
pstmt1.close();
con.close();
basket.emptyBasket();
}
catch(Exception ex)
{
	out.println("error:"+ex);
}
%>
Thanks for your order.
It will be processed within 24 hrs. <br/>
Please note that your order number is : <%=order_id%><br/><br/>
<a href ="<%=response.encodeURL("shop-products.jsp")%> ">
<img src="images\toshop.gif" border ="0" height = 50 width =  120></a>
</div>
<div id ="news">
<h4><b><i><u>News & Events </u></i></b></h4>
<marquee direction="up" scrolldelay="5" scrollamount="2" onmousemove="this.stop()"
onmouseout="this.start()">
<ol>
<li>This is the first news </li>
</marquee>
</div>
<div id ="footer">
<center>copyright &copy; PrasannInfotech.com 2014-15</center>
</div>
</div>
</body>
		</html>
