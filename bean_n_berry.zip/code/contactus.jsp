<%@ page language="java" contentType="text/html" import="prasann.shop.*,java.util.*" errorPage="errorpage.jsp" %>
<HTML>
<HEAD>
<TITLE>M-Kart Shopping website in Java JSP</TITLE>
<link rel="stylesheet" href="style.css" type ="text/css">
 <link href="menu_assets/styles.css" rel="stylesheet" type="text/css" />
</HEAD>

<BODY>
<div id ="wrapper">
<div id ="banner">
<img src="header.jpg"height="172" width="1075">
</div>
 <div id ="navigation">
   <div id='cssmenu'>
<ul>
   <li><a href='shop-products.jsp'><span>Home</span></a></li>
   <li><a href='aboutus.jsp'><span>About us</span></a></li>
   <li><a href='shop-basket.jsp'><span>view cart</span></a></li>
   <li><a href='contactus.jsp'><span>contact us</span></a></li>
</ul>
      </ul>
   </div>
    </div>
   <br>
   <div id="content_area">
<h1>CONTACT US</h1>
    
   Piyoosh Prakhar,<br>
   Lovely Professional University, PUnjab
	 </div>
<div id ="news">
<h4><b><i><u>News & Events </u></i></b></h4>
<marquee direction="up" scrolldelay="5" scrollamount="2" onmousemove="this.stop()"
onmouseout="this.start()">
<ol>
<li>This is the first news </li>
</marquee>
</div>
<div id ="footer">
<center>copyright &copy; Piyoosh Prakhar</center>
</div>
</div>
</BODY>
</HTML>

