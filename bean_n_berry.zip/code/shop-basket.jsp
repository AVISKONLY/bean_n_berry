<%@ page language="java" contentType="text/html" import="prasann.shop.*,java.util.*" errorPage="errorpage.jsp" %>
<HTML>
<HEAD>
<TITLE>M-Kart Shopping website in Java JSP</TITLE>
<link rel="stylesheet" href="style.css" type ="text/css">
 <link href="menu_assets/styles.css" rel="stylesheet" type="text/css" />
</HEAD>

<BODY>
<div id ="wrapper">
<div id ="banner">
<img src="header.jpg"height="172" width="1075">
</div>
 <div id ="navigation">
   <div id='cssmenu'>
<ul>
   <li><a href='shop-products.jsp'><span>Home</span></a></li>
   <li><a href='aboutus.jsp'><span>About us</span></a></li>
   <li><a href='shop-basket.jsp'><span>view cart</span></a></li>
   <li><a href='contactus.jsp'><span>contact us</span></a></li>
</ul>
      </ul>
   </div>
    </div>
   <br>
   <div id="content_area">
<h1>Your Shopping Cart </h1>
<jsp:useBean id ="basket" class="prasann.shop.ShoppingBasket" scope = "session"/>
<%String name = request.getParameter("name");
if(name!=null)
{
	if (name.equals("delete"))
	{
		String item_id=request.getParameter("item_id");
		basket.deleteProduct(item_id);
	}
}
if (basket.getProductNumber() != 0)
{
	%>
<table width ="385" border ="0" cellspacing = "0">
<tr> <td colspan ="6"> Items in your shopping Basket :<br> </td>
</tr>
<tr> 
<td>Ref </td><td>Title</td>
<td>Qty</td><td>price</td><td> Total</td><td></td></tr>

		<% int rowCounter = 0;
		Enumeration products = basket.getProducts();
		while(products.hasMoreElements())
	{
			Product product = (Product)products.nextElement();
			rowCounter++;
			String bg=(rowCounter%2 != 0) ?"#FFFF33":"#FFCC00";
		%>
			<tr bgcolor = "<%= bg %>">
		 <td><%=product.getId() %> </td>
		 <td> <b><%= product.getTitle() %></b></td>
		 <td><%= product.getQuantity() %></td>
		 <td>Rs. <%= product.getPrice() %></td>
		 <td>Rs. <%= product.getTotal() %></td>

		 <td>

 <a href ="<%=response.encodeURL("shop-basket.jsp?name=+delete&item_id="+product.getId()) %>" >Delete</a></td>
	 		 </tr>

	 <% } %>

		 <tr><td> </td><td> </td><td> </td>
			 <td><b>Total </b> </td><td> <%=basket.getTotal()%></td></tr>
			 </table><br/><br/>

<a href ="<%=response.encodeURL("shop-products.jsp")%> ">

	<img src="images\toshop.gif" border ="0"height = 50 width =  110></a>


<a href ="<%=response.encodeURL("shop-emptybasket.jsp")%> ">

	<img src="images\emptybasket.gif" border ="0"height = 50 width =  110></a>

<a href ="<%=response.encodeURL("shop-checkout.jsp")%> ">

	<img src="images\tocheckout.gif" border ="0" height = 50 width =  110></a>
		<% } 
	else
	{
		out.print("your shopping basket is empty!!");
		%>
			<br><br>

<a href ="<%=response.encodeURL("shop-products.jsp")%> ">

	<img src="images\toshop.gif" border ="0" height = 50 width =  110></a>

<% } %> 
</div>
<div id ="news">
<h4><b><i><u>News & Events </u></i></b></h4>
<marquee direction="up" scrolldelay="5" scrollamount="2" onmousemove="this.stop()"
onmouseout="this.start()">
<ol>
<li>This is the first news </li>
</marquee>
</div>
<div id ="footer">
<center>copyright &copy; </center>
</div>
</div>
</BODY>
</HTML>

