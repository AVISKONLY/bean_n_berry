<%@page language="java" contentType="text/html" import="prasann.shop.ShoppingBasket,prasann.shop.Product" errorPage="errorpage.jsp" %>
<%@page language="java" contentType="text/html" import="java.sql.*"  %>
<HTML>
<HEAD>
<TITLE>M-Kart Shopping website in Java JSP</TITLE>
<link rel="stylesheet" href="style.css" type ="text/css">
 <link href="menu_assets/styles.css" rel="stylesheet" type="text/css" />
</HEAD>
<BODY>
<div id ="wrapper">
<div id ="banner">
<img src="header.jpg"height="172" width="1075">
</div>
 <div id ="navigation">
   <div id='cssmenu'>
<ul>
   <li><a href='shop-products.jsp'><span>Home</span></a></li>
   <li><a href='aboutus.jsp'><span>About us</span></a></li>
  <li><a href='shop-basket.jsp'><span>view cart</span></a></li>
   <li><a href='contactus.jsp'><span>contact us</span></a></li>
</ul>
      </ul>
   </div>
    </div>
   <br>
   <div id="content_area">
<h1>Please fill in the details below to checkout : </h1>
<table width ="385" border ="0" cellspacing = "0">
<tr> <td colspan ="4"> Items Available </td>
</tr>
<tr> <td colspan ="4" align = "right">
<a href ="<%=response.encodeURL("shop-basket.jsp")%>">
<img src="images\viewbasket.gif" height = 50 width =  120></a></td>
</tr><tr>
<td><b>Ref </b></td><td><b>Title</b></td>
<td><b>Price</b></td><td></td></tr>
<% 
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saurav","singh");
Statement stmt = con.createStatement();
ResultSet rs = stmt.executeQuery("Select * from items");
int rowCounter=0;
while(rs.next())
{
	 String item_id = rs.getString("itemid");
	 String title = rs.getString("title");
	 String description = rs.getString("description");
	 String price = rs.getString("price");
	 rowCounter++;
	 String bg=(rowCounter%2 != 0) ?"#FF00FF":"#00FFFF";
	 %>
		 <tr bgcolor = "<%= bg %>">
		 <td><%= item_id %> </td>
		 <td> <b><%= title %></b><br/><%= description %></td>
		 <td> Rs. <%= price %></td>
		 <td>
		 <a href ="<%=response.encodeURL("shop-products.jsp?title="+title+"&item_id="+item_id+"&price="+price) %> ">
			 <img src="images\addtobasket.gif" height = 50 width =  100></a></td>
			 </tr>
			 <% }
		 rs.close();
		 con.close();
}
catch(Exception ex)
{
	out.println("Error :"+ex);
}
		 %>
		 </table>
		 <jsp:useBean id="basket" class="prasann.shop.ShoppingBasket" scope = "session"/>
		 <% String title = request.getParameter("title");
		 if ( title!=null)
		 {
			 String item_id = request.getParameter("item_id");
			 double price = Double.parseDouble(request.getParameter("price"));
			 Product item = new Product(item_id, title, price);
			 basket.addProduct(item);
		 }
		 %>
		 </div>
<div id ="news">
<h4><b><i><u>News & Events </u></i></b></h4>
<marquee direction="up" scrolldelay="5" scrollamount="2" onmousemove="this.stop()"
onmouseout="this.start()">
<ol>
<li>This is the first news </li>
</marquee>
</div>
<div id ="footer">
<center>copyright &copy; </center>
</div>
</div>
		 </body>
		 </html>
