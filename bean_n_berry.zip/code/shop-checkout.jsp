<%@ page language="java" contentType="text/html" import="prasann.shop.*,java.util.*" errorPage="errorpage.jsp" %>
<HTML>
<HEAD>
<TITLE>M-Kart Shopping website in Java JSP</TITLE>
<link rel="stylesheet" href="style.css" type ="text/css">
 <link href="menu_assets/styles.css" rel="stylesheet" type="text/css" />
</HEAD>

<BODY>
<div id ="wrapper">
<div id ="banner">
<img src="header.jpg"height="172" width="1075">
</div>
 <div id ="navigation">
   <div id='cssmenu'>
<ul>
   <li><a href='shop-products.jsp'><span>Home</span></a></li>
   <li><a href='aboutus.jsp'><span>About us</span></a></li>
  <li><a href='shop-basket.jsp'><span>view cart</span></a></li>
   <li><a href='contactus.jsp'><span>contact us</span></a></li>
</ul>
      </ul>
   </div>
    </div>
   <br>
   <div id="content_area">
<h1>Please fill in the details below to checkout :</h1>
<jsp:useBean id ="basket" class="prasann.shop.ShoppingBasket" scope = "session"/>

<% if(basket.getProductNumber()!=0)
{
	%>
		<table width ="385" border ="0" cellspacing = "0">
<tr> <td colspan ="5">Your Order :<br> <br></td>
</tr>
<tr> 
<td>Ref </td><td>Title</td>
<td>Quantity</td><td>price</td><td> Total</td><td></td></tr>

		<% int rowCounter = 0;
		Enumeration products = basket.getProducts();
		while(products.hasMoreElements())
	{
			Product product = (Product)products.nextElement();
			rowCounter++;
			String bg=(rowCounter%2 != 0) ?"#FF00FF":"#00FFFF";
		%>
			<tr bgcolor = "<%= bg %>">
		 <td><%=product.getId() %> </td>
		 <td> <b><%= product.getTitle() %></b></td>
		 <td><%= product.getQuantity() %></td>
		 <td>Rs. <%= product.getPrice() %></td>
		 <td>Rs. <%= product.getTotal() %></td>
</tr>
			<% } %>

<tr> <td></td><td></td><td></td><td><b>Total : </b></td><td><%=basket.getTotal() %></td>
</tr>
			 </table>
	<b>Please Enter your details : </b>
	<form method = "post" action = "<%= response.encodeURL("shop-postorder.jsp")%>">

<table width ="385" border ="0" cellspacing = "0">
	<tr><td><b>First Name :</b></td>

	<td><input type = "text" name = "firstname" size=40></td></tr>
	<tr><td><b>SurName :</b></td>

	<td><input type = "text" name = "surname" size=40></td></tr>

			<tr><td><b>Address :</b></td>

	<td><input type = "text" name = "address" size=40></td></tr>
	<tr><td><b>City :</b></td>

	<td><input type = "text" name = "city" size=40></td></tr>

			<tr><td><b>Pin Code :</b></td>

	<td><input type = "text" name = "postcode" size=6></td></tr>

			<tr><td><b>Credit Card type :</b></td>

	<td><input type = "radio" name = "card_type" value="visa"> Visa <input type = "radio" name = "card_type" value="mastercard"> Mastercard<input type = "radio" name = "card_type" value="amex"> Amex</td>
	
	</tr>

		<tr> <td><b> Credit Card Number :</b></td>

			<td><input type = "text" name ="card_number" size=40></td>
				</tr></table>
	<input type ="hidden" name ="totalvalue" value="<%=basket.getTotal() %>"> <br>

	
	<a href ="<%=response.encodeURL("shop-products.jsp")%> ">

	<img src="images\toshop.gif" border ="0" height = 50 width =  120></a>

	<input type ="submit" name ="checkout" value ="press to send your order ">
		</form>
		<% } else
		{
		out.print("There are no items in your shopping basket .......!");
		}
		%>
</div>
<div id ="news">
<h4><b><i><u>News & Events </u></i></b></h4>
<marquee direction="up" scrolldelay="5" scrollamount="2" onmousemove="this.stop()"
onmouseout="this.start()">
<ol>
<li>This is the first news </li>
</marquee>
</div>
<div id ="footer">
<center>copyright &copy; </center>
</div>
</div>
</BODY>
</HTML>

