package prasann.shop;
import java.util.*;
public class  ShoppingBasket
{
	Vector products;
	public ShoppingBasket()
	{
		products = new Vector();
	}
	public void addProduct(Product product)
	{
		boolean flag = false;
		for (Enumeration enum1 = getProducts();enum1.hasMoreElements() ; )
		{
			Product item = (Product)enum1.nextElement();
			if(item.getId().equals(product.id))
			{
				flag= true;
				item.quantity++;
				break;
			}
		}
		if(!flag)
		{
			products.addElement(product);
		}
	}
	public void deleteProduct(String  str)
	{
		for(Enumeration enum1 = getProducts(); enum1.hasMoreElements();)
		{
			Product item = (Product)enum1.nextElement();
			if(item.getId().equals(str))
			{
				products.removeElement(item);
				break;
			}
		}
	}
	public void emptyBasket()
	{
		products = new Vector();
	}
	public int getProductNumber()
	{
		return products.size();
	}
	public Enumeration getProducts()
	{
		return products.elements();
	}
	public double getTotal()
	{
		Enumeration enum1 = getProducts();
		double total;
		Product item;
		for (total=0.0D;enum1.hasMoreElements() ;total+=item.getTotal() )
		{
			item = (Product)enum1.nextElement();

		}
		return total;
	}

}
