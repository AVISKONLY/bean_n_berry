package prasann.shop;
public class  Product
{
/* define variable */
String id, title;
int quantity;
double price;

	public Product (String id, String title, double price)
	{
		this.quantity = 1;
		this.id = id;
		this.title = title;
		this.price = price;
	}
	public String getId()
	{
		return id;
	}
	public double getPrice()
	{
		return price;
	}
	public int getQuantity()
	{
		return quantity;
	}
	public String getTitle()
	{
		return title;
	}

	public double getTotal()
	{
		return price * (double) quantity;
	}
}
