<%@ page language="java" contentType="text/html" import="prasann.shop.*,java.util.*" errorPage="errorpage.jsp" %>
<HTML>
<HEAD>
<TITLE>M-Kart Shopping website in Java JSP</TITLE>
<link rel="stylesheet" href="style.css" type ="text/css">
 <link href="menu_assets/styles.css" rel="stylesheet" type="text/css" />
</HEAD>

<BODY>
<div id ="wrapper">
<div id ="banner">
<img src="header.jpg"height="172" width="1075">
</div>
 <div id ="navigation">
   <div id='cssmenu'>
<ul>
   <li><a href='shop-products.jsp'><span>Home</span></a></li>
   <li><a href='aboutus.jsp'><span>About us</span></a></li>
   <li><a href='shop-basket.jsp'><span>view cart</span></a></li>
   <li><a href='contactus.jsp'><span>contact us</span></a></li>
</ul>
      </ul>
   </div>
    </div>
   <br>
   <div id="content_area">
<h1>About Us</h1>
    
 <p> This is a project to simulate M-Kart Shopping website in Java JSP in Object Oriented environment. This system makes certain computerized facilities to implement and maintain customer records and their daily transaction records. The Gift Store keeps certain information for facilitating warranty (in case of electronic items etc.) at different service centers etc. as follows.</p>
<p>The M-Kart Shopping website in Java JSP website will have:</p>
<ol type="(1)">
<li>Home page </li>
<li>Product query and information display</li>
<li>Login </li>
<ol type="(a)">
<li>As customer </li>
<li>As Administrator</li> 
</ol>

<li>	Login Module : </li>

<br>(a)	Create user module 
         <p>To login as customer it is mandatory to create a customer account. In the login module the system will ask following information to be stored in the table. </p>
<br>(5)	Customer login

            <p>This module will ask username and password and will check it from the oracle  Database. If the username and password are correct then it will login. Otherwise it will display the error message. After login, the customer can book a  product and view his last transactions. He can also edit his profile. </p>

<br>(6)	Administrator login

  <p> This module will ask username and password and will check it from the oracle Database and will check its privilege. If the username and password are correct and of the administrator then it will login. Otherwise it will display the error message. Further it will redirect to the administrator page from where he can enter the product details , modify the price, stock etc.</p>


<br> (7) Product booking module. 
<br>(a)	New Gift
<p>A customer can book a new Gift and can get the system generated booking information report. Which with the enclosures such as Address of the person to whom the gift is to be delivered etc.</p>

<br>(b)	Old Gift
<p>An existing customer can book/ change to a new Gift and can get the system generated booking information report.</p>
<br>(8) Report : 
 (c)Yearly booking report(a) Day wise booking report
(b)Monthly booking report

(d)Stock report
(e)Purchase report
"	Day wise
"	Monthly
"	Yearly
"	Product wise
(f)Sales report.
"	Day wise
"	Monthly
"	Yearly
"	Product wise
"	Customer wise

	 </div>
<div id ="news">
<h4><b><i><u>News & Events </u></i></b></h4>
<marquee direction="up" scrolldelay="5" scrollamount="2" onmousemove="this.stop()"
onmouseout="this.start()">
<ol>
<li>This is the first news </li>
</marquee>
</div>
<div id ="footer">
<center>copyright &copy; Piyoosh Prakhar, 2023-24</center>
</div>
</div>
</BODY>
</HTML>

